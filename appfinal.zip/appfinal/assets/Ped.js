import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  StatusBar,
  ScrollView,
  Image,
} from 'react-native';

const pd = (navigation) => {
  return (
    <ScrollView style={style.container}>
      <StatusBar backgroundColor={'red'} />
      <View
        style={{
          backgroundColor: 'red',
          paddingHorizontal: 15,
          paddingVertical: 15,
          height: 50,
          marginTop: 20,
        }}>
        <TouchableOpacity>
          <Text style={{ color: 'white' }}>Sair</Text>
        </TouchableOpacity>
      </View>
      <View style={style.containerIn}>
        <View style={style.containerIn1}>
          <Image
            source={require('../Imagem/Hambur1.jpeg')}
            style={style.cardimage}
          />
        </View>

        <View style={style.containerIn2}>
          <View style={style.containerIn2_s1}>
            <Text style={style.containerIn2_s1_nome}>Colosso</Text>
            <Text style={style.containerIn2_s1_preco}>R$45.00</Text>
          </View>

          
            <View style={style.containerIn2_s2}>
              <Text style={style.containerIn2_s2_head}>sobre o item</Text>
              <Text style={style.containerIn2_s2_descricao}>Bom lanche</Text>
              <Text style={style.containerIn2_s2_carne}>Carne</Text>

            </View>

            <View style={style.containerIn2_s3}>
              <Text style={style.containerIn2_s3_res}>Restaurante</Text>
              <Text style={style.containerIn2_s3_resd}>Flavo Race</Text>

            </View>
          

        </View>

        <View style={style.containerIn3}>
         <TouchableOpacity style={style.containerIn3_buy}>
          <Text style={style.containerIn3_buy_txt} onPress={() => navigation.navigate(Carinho)}>Pagar</Text>
        </TouchableOpacity>
        </View>

      </View>
    </ScrollView>
  );
};
export default pd;

const style = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ebebeb',
    width: '100%',
    height: '100%',
  },
  containerIn:{
    backgroundColor: '#ebebeb',
  },
  containerIn1:{
    width: '100%',
    height: 220,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center'
  },
  cardimage: {
    width: '100%',
    height: '100%',
  },
  containerIn2:{
    width: '100%',
    padding: 20,
    position:'relative',
    top: -30,
    backgroundColor:'#ebebeb',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  }, 
    containerIn2_s1:{
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 10,
      paddingHorizontal: 10
    },
    containerIn2_s1_nome:{
      fontSize: 25,
      fontWeight: '600',
      width: 220,
      marginRight: 10
    },
    containerIn2_s1_preco:{
      fontSize: 26,
      fontWeight: '600',
    },
    containerIn2_s2:{
      paddingHorizontal: 15,
      paddingVertical: 10,
      borderRadius: 20,
      backgroundColor: 'white'
    },
    containerIn2_s2_head:{
      fontSize: 18,
      fontWeight: '600',
    },
    containerIn2_s2_descricao:{
      fontSize: 15,
      paddingTop: 10,
    },
    containerIn2_s2_carne:{
      backgroundColor: 'green',
      color: 'white',
      paddingHorizontal: 17,
      paddingVertical: 5,
      borderRadius: 10,
      width: 70,
      alignItems: 'center',
      marginTop: 5
    },
    containerIn2_s3:{
      backgroundColor: '#F2F2F2',
      marginVertical: 10,
      padding: 20,
      borderRadius: 20,
      width: '100%',
      elevation: 2,
      alignItems: 'center'
    },
    containerIn2_s3_res:{
      color: 'grey',
      fontSize: 20,
      fontWeight: '600'
    },
    containerIn2_s3_resd:{
      color: '#9c9c9c',
      fontWeight: '600',
      marginVertical: 10,
      fontSize: 16
    },
    containerIn3:{
      width: '100%',
      justifyContent: 'center',
      alignItems: 'center',
      marginTop: 0,
      flexDirection: 'row'
    },
    containerIn3_buy:{
      width: '90%',
      height: 50,
      backgroundColor: '#FF3F00',
      borderRadius: 25,
      alignItems: 'center',
      justifyContent: 'center',
      elevation: 2,
      color: 'black',
      margin: 10,
      alignSelf: 'center'
    },
    containerIn3_buy_txt:{
      paddingVertical: 5,
      fontSize: 17,
      borderRadius: 10,
      textAlign: 'center',
      fontWeight: '600',
      alignSelf: 'center'
    }
});
