import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const App = (navigation) => {
  const itemsNoCarrinho = [
    { id: 1, nome: 'Hamburge com batata', preco: 45, quantidade: 0, imagem: require('../Imagem/Hambur1.jpeg') }
  ];

  const [cartItems, setCartItems] = useState(itemsNoCarrinho);

  const aumentarQuantidade = (index) => {
    const novosItens = [...cartItems];
    novosItens[index].quantidade++;
    setCartItems(novosItens);
  };

  const diminuirQuantidade = (index) => {
    const novosItens = [...cartItems];
    if (novosItens[index].quantidade > 0) {
      novosItens[index].quantidade--;
      setCartItems(novosItens);
    }
  };

  const calcularSubtotal = () => {
    return cartItems.reduce((total, item) => total + item.preco * item.quantidade, 0);
  };

  const calcularDesconto = (subtotal) => {
    // Aplica um desconto se houver mais de 3 itens
    return subtotal > 3 ? 2 : 0;
  };

  const calcularFrete = () => {
    // Aumenta a taxa de entrega a cada dois itens
    const quantidadeItens = cartItems.reduce((total, item) => total + item.quantidade, 0);
    return Math.floor(quantidadeItens / 2) * 3.5;
  };

  const subtotal = calcularSubtotal();
  const desconto = calcularDesconto(subtotal);
  const frete = calcularFrete();
  const total = subtotal + frete - desconto;

  return (
    <View style={styles.container}>
      {cartItems.map((item, index) => (
        <View key={item.id}>
          {/* Adicionando uma imagem acima de cada item */}
          <Image source={item.imagem} style={styles.itemImage} />
          <View style={styles.itemContainer}>
            <Text style={styles.itemName}>{item.nome}</Text>
            <View style={styles.quantityContainer}>
              <TouchableOpacity onPress={() => diminuirQuantidade(index)}>
                <Text style={styles.quantityButton}>-</Text>
              </TouchableOpacity>
              <Text style={styles.quantityText}>{item.quantidade}</Text>
              <TouchableOpacity onPress={() => aumentarQuantidade(index)}>
                <Text style={styles.quantityButton}>+</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.itemTotal}>{item.preco * item.quantidade}</Text>
          </View>
        </View>
      ))}
      <View style={styles.summaryContainer}>
        <Text style={styles.summaryText}>Subtotal: {subtotal}</Text>
        <Text style={styles.summaryText}>Frete: {frete}</Text>
        <Text style={styles.summaryText}>Desconto: {desconto}</Text>
        <Text style={styles.totalText}>Total: {total}</Text>
      </View>

      <View style={styles.containerIn3}>
         <TouchableOpacity style={styles.containerIn3_buy}>
          <Text style={styles.containerIn3_buy_txt} onPress={()  => navigation.navigate(Pagar)}>carinho</Text>
        </TouchableOpacity>
        </View>

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  itemContainer: {
    width: '100%',
    padding: 20,
    position:'relative',
    top: -30,
    backgroundColor:'#ebebeb',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  itemImage: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
    marginBottom: 8,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20
  },
  itemName: {
    fontSize: 16,
    marginRight: 8,
    backgroundColor: ''
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 'auto',
    backgroundColor: ''
  },
  quantityButton: {
    fontSize: 20,
  },
  quantityText: {
    fontSize: 16,
    marginHorizontal: 8,
  },
  itemTotal: {
    fontSize: 16,
    marginLeft: 16,
  },
  summaryContainer: {
    width: '100%',
    padding: 20,
    position:'relative',
    top: -30,
    backgroundColor:'#ebebeb',
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20
  },
  summaryText: {
    fontSize: 16,
    marginBottom: 8,
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  containerIn3:{
      width: '100%',
      justifyContent: 'center',
      alignItems: 'center',
      marginTop: 0,
      flexDirection: 'row'
    },
    containerIn3_buy:{
      width: '90%',
      height: 50,
      backgroundColor: '#FF3F00',
      borderRadius: 25,
      alignItems: 'center',
      justifyContent: 'center',
      elevation: 2,
      color: 'black',
      margin: 10,
      alignSelf: 'center'
    },
    containerIn3_buy_txt:{
      paddingVertical: 5,
      fontSize: 17,
      borderRadius: 10,
      textAlign: 'center',
      fontWeight: '600',
      alignSelf: 'center'
    }
});

export default App;