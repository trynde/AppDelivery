import {StyleSheet, Text, View, Statusbar} from 'react-native'
import App from './App'
import Cadastro from './Cadastro'
import navapp from './navegar/navapp'

export default function c(){
  <View style={style.container}>
    <Statusbar style="auto"/>
    {/*<App/>*/}
    <nacapp/>
  </View>
}

const style = StyleSheet.create({
  container:{
    flex: 1,
    borderStartColor: "#fff",
    alignItems: 'center',
    justifyContent: 'center'
  }
})