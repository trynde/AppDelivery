import {StyleSheet, Text, View} from 'react-native'
import appstack from './appstack'
import authStack from './authStack'
const navapp = () => {
  return (
    <>
       <appstack /> 
      {/*<authStack />*/}
    </>
  )
}

export default navapp

const style = StyleSheet.create({})