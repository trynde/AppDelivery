import { StyleSheet, Text, View, Image } from 'react-native';
import Swiper from 'react-native-swiper';

const App = () => {
  return (
    <View style={style.container}>
      <Swiper autoplay={true} autoplayTimeout={5} showsButtons={true} dotColor={'red'} activeDotColor={'black'}>

        <View style={style.slide}>
          <Image source={require('../Imagem/ofetta2.png')} style={style.image} />
        </View>
        <View style={style.slide}>
          <Image source={require('../Imagem/oferta1.png')} style={style.image} />
        </View>
        <View style={style.slide}>
          <Image source={require('../Imagem/oferta3.png')} style={style.image} />
        </View>
      </Swiper>
    </View>
  );
};
export default App;

const style = StyleSheet.create({
  container: {
    width: '100',
    height: 150,
  },
  image:{
    width:"100%",
    height:'100%',
    borderRadius: 20
  },
  slide:{
    width:'100%',
    height: '100%',
    justifyContent: 'center',
    alignContent: 'center'
  }
});
