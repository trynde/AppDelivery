import {StyleSheet, Text, View, TouchableOpacity, StatusBar} from 'react-native'
import { AntDesign } from '@expo/vector-icons';
import { FontAwesome } from '@expo/vector-icons';

const App = () => {
  return(
     <View style={style.mainContainer}>
      <StatusBar backgroundColor={'red'}/>

      <View style={style.container}>
        <TouchableOpacity style={{flexDirection: 'row'}}>
          <AntDesign name="bars" size={28} color="grey" style={{paddingVertical: 6}}/>
            <View style={{paddingHorizontal: 5}}>
            </View>
        </TouchableOpacity>

        <TouchableOpacity>
        <View> 
             <FontAwesome name="user" size={28} color="grey" style={{paddingVertical: 6}}/>
            </View>
        </TouchableOpacity>
      </View>
    </View>
  )
}
export default App

const style = StyleSheet.create({
  container:{
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 29,
   // borderBottomWidth: 1,
   // borderColor: 'grey',
    justifyContent: 'space-between',
    height: 60,
    backgroundColor: 'white',
    paddingHorizontal: 20,
    paddingVertical: 10
  }
})