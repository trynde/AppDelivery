import { StyleSheet, Text, View, TouchableOpacity, Image, ScrollView} from 'react-native';

const App = (navigation) => {
  return (
    <View style={style.container}>
      <Text style={style.card}>Comida especial da Semana</Text>
      
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>

      <TouchableOpacity style={style.carde}>
        <View>
          <Image
            source={require('../Imagem/Hambur1.jpeg')}
            style={style.cardimage}
          />
        </View>

        <View style={style.card1}>
          <Text style={style.card1txt}>Colossos</Text>

          <View style={style.card2}>
            <Text style={style.card2txt1}>Fast Food</Text>
            <Text style={style.card2txt1}>
              Preço -{' '}
              <Text style={{textDecorationLine: 'line-through' }}>
                R$ 55.00
              </Text>
              <Text>R$ 45.00</Text>
            </Text>
            <Text style={style.card2txt3}>Carne</Text>
          </View>
        </View>
      </TouchableOpacity>

      <TouchableOpacity style={style.carde} onPress={()  => navigation.navigate('ped')}>
        <View>
          <Image
            source={require('../Imagem/Hambur2.jpeg')}
            style={style.cardimage}
          />
        </View>

        <View style={style.card1}>
          <Text style={style.card1txt}>Pompeia</Text>

          <View style={style.card2}>
            <Text style={style.card2txt1}>Fast Food</Text>
            <Text style={style.card2txt1}>
              Preço -{' '}
              <Text style={{textDecorationLine: 'line-through' }}>
                R$ 60.00
              </Text>
              <Text>R$ 50.00</Text>
            </Text>
            <Text style={style.card2txt3}>Carne</Text>
          </View>
        </View>
      </TouchableOpacity>

      </ScrollView>
    </View>
  );
};
export default App;

const style = StyleSheet.create({
  container: {
    marginVertical: 10,
  },
  card: {
    fontSize: 20,
    fontWeight: '600',
    marginHorizontal: 10,
    paddingLeft: 5,
  },
  cardimage: {
    width: '100%',
    height: 150,
    borderTopLeftRadius: 17,
    borderTopRightRadius: 17,
  },
  carde: {
    width: 300,
    height: 200,
    marginLeft: 10,
    marginTop: 10,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'grey',
  },
  card1: {
    marginHorizontal: 3,
    marginTop: 3,
  },
  card1txt: {
    fontSize: 16,
    fontWeight: '600',
    marginHorizontal: 5,
  },
  card2: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 6,
  },
  card2txt1: {
    fontSize: 12,
    marginRight: 10,
    fontWeight: '500',
  },
  card2txt3:{
    height: 20,
    borderRadius: 50,
    backgroundColor: 'red',
    fontSize: 10,
    fontWeight: '500',
    color: 'white',
    textAlign: 'center',
    justifyContent: 'center',
    paddingHorizontal: 7
  }
});
