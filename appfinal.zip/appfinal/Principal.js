import {StyleSheet, Text, View, StatusBar, TouchableOpacity,
} from 'react-native';
import react from 'react'
import Cabeca from './assets/Cabeca';
import Categoria from './assets/Categoria';
import Oferta from './assets/Ofertas'
import Comida from './assets/Comida'
import { FontAwesome } from '@expo/vector-icons';


const Principal = (navigation) => {
  return (
    <View style={style.mainContainer}>
      <StatusBar backgroundColor={'red'} />

      <Cabeca />

      <TouchableOpacity style={style.pesqbox}>
        <FontAwesome
          name="search"
          size={24}
          color="black"
          style={{ color: 'red' }}
        />
        <Text style={style.input}>pesquisar</Text>
      </TouchableOpacity>

      <Categoria />
      <Oferta  />
      <Comida onPress={()  => navigation.navigate('ped')}/>
    </View>
  );
};
export default Principal;

const style = StyleSheet.create({
  mainContainer: {
    flex: 1,
    height: '100%',
  },
  pesqbox: {
    flexDirection: 'row',
    width: '92%',
    backgroundColor: 'white',
    alignItems: 'center',
    padding: 10,
    marginVertical: 10,
    borderRadius: 20,
    alignSelf: 'center',
    elevation: 2,
  },
  input: {
    marginLeft: 10,
    width: '90%',
    fontSize: 16,
    color: 'grey',
  },
});
