import {StyleSheet, Text, View, TextInput, TouchableOpacity, StatusBar, Button} from 'react-native'
import { Principal } from '@react-navigation/native';
import principal from './Principal'

const App = (navigation) => {
  return(
    <View style={style.container}>
    <StatusBar backgroundColor={'red'}/>
    <View style={{paddingVertical: 12, width:'95%', alignSelf:'center', marginBottom: 10}}>
    <Text style={{alignSelf:'center', fontSize:25, fontWeight:'700', }}>Flavor Race</Text>
    </View>
    <TextInput
    placeholder='E-mail'
    keyboardType='email-addres'
    style={style.input}
    />
     <TextInput
    placeholder='Senha'
    style={style.input}
    />
    <TouchableOpacity style={style.loginbotao} onPress={() => navigation.navigate(Principal)}>
    <Text style={style.loginbotaotxt}>Login</Text>
    </TouchableOpacity>

    <View style={{marginTop:15, width:'93%', alignSelf:'center', flexDirection:'row', justifyContent: 'space-between'}}>
      <View style={{paddingLeft: 10}}>
        <Text>Não possui conta?</Text>
      </View>

      <View style={{backgroundColor:'red', borderRadius: 25, alignSelf:'center', padding: 5, elevation: 1}}>
        <TouchableOpacity >
          <Text style={{fontSize: 17, fontWeight:'600', color:'white',alignSelf:'center', paddingHorizontal: 10}}>Cadastre</Text>
        </TouchableOpacity>
      </View>
    </View>

    </View>
  )
}
export default App

const style = StyleSheet.create({
  container:{
    flex: 1,
    justifyContent:'center',
    //backgroundColor:'green',
    width:'100%'
  },
  input:{
    padding: 10,
    borderColor:'green',
    borederWindth: 1,
    borderRadius: 25,
    marginBottom: 10,
    width: '95%',
    alignSelf:'center'
  },
  loginbotao: {
    backgroundColor:'red',
    borderRadius: 25,
    width: '95%',
    alignSelf:'center',
    padding: 10,
    elevation: 2
  },
  loginbotaotxt:{
    fontSize: 17,
    fontWeight:'600',
    color:'white',
    alignSelf:'center'
  }
})