import { StyleSheet, Text, View, NavigationContainer } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/stack';
import { navigationContainer } from '@react-navigation/native';
import Principal from '../Principal'
import Comida from '../assets/Comida'
import Carinho from '../assets/Carinho'
import Ped from '../assets/Ped'
import Pagar from '../assets/Pagar'
import Rastrear from '../assets/rastrear'

const Stack = createNativeStackNavigator();

const authStack = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName='app'>
        <Stack.Screen name="TelaPrincipal" component={Principal} />
        <Stack.Screen name="Comida" component={Comida}  />
        <Stack.Screen name="pedido" component={Ped} />
        <Stack.Screen name="carro" component={Carinho}  />
        <Stack.Screen name="pagamento" component={Pagar}  />
        <Stack.Screen name="ras" component={Rastrear}  />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default authStack;

const style = StyleSheet.create({});
