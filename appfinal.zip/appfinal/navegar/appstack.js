import { StyleSheet, Text, View, NavigationContainer } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/stack';
import { navigationContainer } from '@react-navigation/native';
import Principal from '../Principal';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const homestack = () => (
  <Stack.Navigator>
    <Stack.Screen name="central" component={Principal} />
  </Stack.Navigator>
);

const appstack = () => {
  return (
    <NavigationContainer>
      {/*<Stack.Navigator>
    <Stack.Screen name="central" component={Principal}/>
      <Stack.Screen name="Home" component={Home}/>
      <Stack.Screen name="Home" component={Home}/>
      <Stack.Screen name="Home" component={Home}/>
      <Stack.Screen name="Home" component={Home}/> 
    </Stack.Navigator> */}

      <Tab.Navigator>
        <Tab.Screen name="central" component={Principal} />
        <Tab.Screen name="central1" component={Principal} />
        <Tab.Screen name="central2" component={Principal} />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

export default appstack;

const style = StyleSheet.create({});
