import {StyleSheet, Text, View, ScrollView, TouchableOpacity, Image} from 'react-native'

const App = () => {
  return(
    <View style={style.container}>
      <Text style={style.head}>Categorias</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <TouchableOpacity style={[style.box, {backgroundColor: '#c4c4c4'},]}>
          <Image source={require('../Imagem/icon.png')} style={style.image} />

          <Text style={style.text}>Carne</Text>
        </TouchableOpacity>

        <TouchableOpacity style={[style.box, {backgroundColor: '#c4c4c4'}]}>
          <Image source={require('../Imagem/iconf.png')} style={style.image} />

          <Text style={style.text}>Frango</Text>
        </TouchableOpacity> 
      </ScrollView>
    </View>
  )
}
export default App

const style = StyleSheet.create({
  container:{
    width: '100%',
    borderRadius: '10'
  },
  head:{
    fontSize: 20,
    fontWeight:'600',
    margin: 10,
    paddingBottom: 5,
    paddingLeft: 5
  },
  image:{
    width: 20,
    height:20
  },
  box:{
    flexDirection: 'row',
    marginHorizontal: 50,
    marginBottom: 10,
    padding: 10,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 2
  },
  text:{
    marginLeft: 5,

  }
})