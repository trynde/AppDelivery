import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Entypo } from '@expo/vector-icons';
import Rastrar from './rastrear'

const CheckoutScreen = (navigation) => {
  return (
    <View style={styles.container}>
      <View style={styles.address}>
        <Entypo
          name="location-pin"
          size={28}
          color="black"
          style={{ paddingVertical: 6 }}
        />
        <Text style={styles.title}>Seu endereço</Text>
        <Text style={styles.text}>Avenida Nações Unidas, 165</Text>
      </View>
      <View style={styles.payment}>
        <Text style={styles.title}>Métodos de pagamento</Text>
        <Text style={styles.textC}>VISA Cartão de crédito</Text>
        <Text style={styles.text}>PIX</Text>
      </View>
      <View style={styles.total}>
        <Text style={styles.title}>Total</Text>
        <Text style={styles.text}>R$ 115,70</Text>
      </View>
      <View style={styles.button} onPress={() => navigation.navigate(Rastrar)}>
        <TouchableOpacity>
          <Text style={styles.buttonText}>Pagar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  address: {
    marginBottom: 16,
    backgroundColor: 'grey',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    flexDirection: 'row',
  },
  payment: {
    marginBottom: 16,
    backgroundColor: 'grey',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  total: {
    marginBottom: 16,
    backgroundColor: 'grey',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
    padding: 10,
  },
  text: {
    fontSize: 14,
    marginBottom: 8,
    padding: 10,
  },
  button: {
    backgroundColor: '#007BFF',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 4,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  textC: {
    fontSize: 14,
    marginBottom: 8,
    padding: 10,
    backgroundColor: '#ebebeb',
  },
});

export default CheckoutScreen;
