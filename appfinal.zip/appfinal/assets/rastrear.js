import React from 'react';
import { View, Image, StyleSheet, TouchableOpacity} from 'react-native';
import Text from 'react-native-text';

const App = (navigation) => {
  return (
    <View style={styles.container}>
      <Image source={require('../Imagem/Mapa.png')} style={styles.image} />

      <View style={styles.textContainer}>
<TouchableOpacity>
          <Text style={{ color: 'Black' }}>Sair</Text>
        </TouchableOpacity>
        <Text style={styles.address1}>Seu endereço</Text>
      <Text style={styles.address}>
        Avenida Nações Unidas, 165
        Marginal Pinheiros
        Avenida das Nações Unidas
      </Text>
      
      <Text style={styles.time}>Tempo estimado de entrega:</Text>
      <Text style={styles.time}>15:30 á 15:50</Text>

      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  textContainer: {
    position: 'absolute',
    top: 600, // Ajuste conforme necessário
    left: 20, // Ajuste conforme necessário
    right: 20, // Ajuste conforme necessário
    backgroundColor: 'rgba(255, 255, 255, 0.7)', // Fundo transparente
    padding: 10,
    borderRadius: 10,
  },
  address: {
   padding: 10,
    fontSize: 18,
    
    backgroundColor:'#ebebeb',
    borderBottomRightRadius:20,
    borderBottomLeftRadius:20
 },
  address1:{
    padding: 10,
    backgroundColor:'#ebebeb',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    
 },
});

export default App;
