import {StyleSheet, Text, View, StatusBar,TextInput, TouchableOpacity} from 'react-native'

const Cadastro = () => {
  return(
    <View style={style.container}>
    <StatusBar backgroundColor={'red'}/>
    <View style={{paddingVertical: 12, width:'95%', alignSelf:'center', marginBottom: 10}}>
    <Text style={{alignSelf:'center', fontSize:25, fontWeight:'700', }}>Login</Text>
    </View>
    <TextInput
    placeholder='E-mail'
    keyboardType='email-addres'
    style={style.input}
    />
     <TextInput
    placeholder='Senha'
    style={style.input}
    />
    <TouchableOpacity style={style.loginbotao}>
    <Text style={style.loginbotaotxt}>Login</Text>
    </TouchableOpacity>

    <View style={{marginTop:15, width:'93%', alignSelf:'center', flexDirection:'row', justifyContent: 'space-between'}}>
      <View style={{paddingLeft: 10}}>
        <Text>Não possui conta?</Text>
      </View>

      <View style={{backgroundColor:'red', borderRadius: 25, alignSelf:'center', padding: 5, elevation: 1}}>
        <TouchableOpacity >
          <Text style={{fontSize: 17, fontWeight:'600', color:'white',alignSelf:'center', paddingHorizontal: 10}}>Cadastre</Text>
        </TouchableOpacity>
      </View>
    </View>

    </View>
  )
}
export default Cadastro

const style = StyleSheet.create({
  container:{
    flex: 1,
    justifyContent:'center',
    //backgroundColor:'green',
    width:'100%'
  }
})